import { Component } from '@angular/core';

@Component({
  selector: 'app-minileftbar',
  templateUrl: './minileftbar.component.html',
  styleUrls: ['./minileftbar.component.css']
})
export class MinileftbarComponent {

}
